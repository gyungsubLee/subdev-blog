# 필요한 라이브러리들을 가져오기 (import)
import os          # 운영체제와 관련된 기능 (환경변수 읽기 등)
import requests    # 인터넷에 HTTP 요청을 보내는 라이브러리
import json        # JSON 데이터를 다루는 라이브러리
from dotenv import load_dotenv  # .env 파일에서 환경변수를 읽어오는 라이브러리
import time        # 시간 관련 기능 (지연시간 등)

# .env 파일에서 API 키들을 읽어와서 환경변수로 설정
# .env 파일은 비밀번호나 API 키 같은 민감한 정보를 저장하는 파일
load_dotenv()

class SearchManager:
    """
    검색 관리자 클래스
    네이버 블로그, 네이버 뉴스, 구글 검색을 통합해서 관리하는 클래스
    클래스는 관련된 기능들을 하나로 묶어놓은 코드 틀이라고 생각하면 됨
    """
    
    def __init__(self):
        """
        클래스가 처음 만들어질 때 실행되는 초기화 함수
        .env 파일에서 API 키들을 읽어와서 변수에 저장
        """
        # os.getenv()는 환경변수(컴퓨터에 저장된 설정값)에서 값을 가져오는 함수
        self.naver_client_id = os.getenv('NAVER_CLIENT_ID')           # 네이버 API 아이디
        self.naver_client_secret = os.getenv('NAVER_CLIENT_SECRET')   # 네이버 API 비밀키
        self.google_api_key = os.getenv('GOOGLE_API_KEY')             # 구글 API 키
        self.google_cse_id = os.getenv('GOOGLE_SEACH_ENGINE_ID')      # 구글 검색엔진 아이디
    
    def search_naver_blog(self, query, display=10):
        """
        네이버 블로그를 검색하는 함수
        query: 검색할 키워드 (예: "파이썬 프로그래밍")
        display: 가져올 결과 개수 (기본값: 10개)
        """
        try:  # 오류가 발생할 수 있는 코드를 try 안에 작성
            # 네이버 블로그 검색 API의 인터넷 주소
            url = "https://openapi.naver.com/v1/search/blog"
            
            # API 요청할 때 보내야 하는 인증 정보 (네이버가 누구인지 확인용)
            headers = {
                "X-Naver-Client-Id": self.naver_client_id,        # 네이버 API 아이디
                "X-Naver-Client-Secret": self.naver_client_secret  # 네이버 API 비밀키
            }
            
            # 검색 조건들 (어떤 키워드로, 몇 개를, 어떤 순서로 검색할지)
            params = {
                "query": query,    # 검색할 키워드
                "display": display, # 가져올 결과 개수
                "sort": "sim"      # 정확도순으로 정렬 (sim = similarity)
            }
            
            # 네이버 서버에 검색 요청을 보내기
            # requests.get()은 인터넷으로 데이터를 요청하는 함수
            response = requests.get(url, headers=headers, params=params)
            
            # 요청이 성공했는지 확인 (실패하면 오류 발생)
            response.raise_for_status()
            
            # 네이버에서 받은 응답을 JSON 형태로 변환
            # JSON은 데이터를 주고받을 때 사용하는 표준 형식
            data = response.json()
            
            # 결과를 저장할 빈 리스트 만들기
            results = []
            
            # 네이버에서 받은 검색 결과들을 하나씩 처리
            # data.get('items', [])는 'items' 키의 값을 가져오는데, 없으면 빈 리스트 반환
            for item in data.get('items', []):
                # 각 검색 결과를 우리가 원하는 형태로 변환해서 리스트에 추가
                results.append({
                    "title": self._clean_html(item.get('title', '')),        # 제목 (HTML 태그 제거)
                    "content": self._clean_html(item.get('description', '')), # 내용 (HTML 태그 제거)
                    "url": item.get('link', ''),                             # 블로그 링크
                    "source": "네이버 블로그"                                 # 어느 사이트에서 온 결과인지 표시
                })
            
            return results  # 처리된 결과 리스트를 반환
            
        except Exception as e:  # 오류가 발생하면 이 부분이 실행됨
            print(f"네이버 블로그 검색 오류: {e}")  # 오류 메시지 출력
            return []  # 빈 리스트 반환 (오류 발생 시)
    
    def search_naver_news(self, query, display=10):
        """
        네이버 뉴스를 검색하는 함수
        query: 검색할 키워드 (예: "AI 기술")
        display: 가져올 결과 개수 (기본값: 10개)
        """
        try:  # 오류 처리를 위한 try 블록
            # 네이버 뉴스 검색 API의 인터넷 주소
            url = "https://openapi.naver.com/v1/search/news"
            
            # API 요청에 필요한 인증 정보
            headers = {
                "X-Naver-Client-Id": self.naver_client_id,        # 네이버 클라이언트 ID
                "X-Naver-Client-Secret": self.naver_client_secret  # 네이버 클라이언트 시크릿
            }
            
            # 뉴스 검색 조건 설정
            params = {
                "query": query,     # 검색할 키워드
                "display": display, # 가져올 뉴스 개수
                "sort": "date"      # 최신 날짜순으로 정렬
            }
            
            # 네이버에 뉴스 검색 요청 보내기
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()  # 요청 성공 여부 확인
            
            # 받은 응답을 JSON으로 변환
            data = response.json()
            
            # 결과를 담을 빈 리스트 생성
            results = []
            
            # 각 뉴스 기사를 하나씩 처리
            for item in data.get('items', []):
                # 뉴스 정보를 정리해서 리스트에 추가
                results.append({
                    "title": self._clean_html(item.get('title', '')),        # 뉴스 제목 (HTML 태그 제거)
                    "content": self._clean_html(item.get('description', '')), # 뉴스 요약 (HTML 태그 제거)
                    "url": item.get('link', ''),                             # 뉴스 링크
                    "source": "네이버 뉴스"                                   # 검색 소스 표시
                })
            
            return results  # 처리된 뉴스 결과 반환
            
        except Exception as e:  # 에러가 발생했을 때 처리
            print(f"네이버 뉴스 검색 오류: {e}")
            return []  # 빈 리스트 반환
    
    def search_google(self, query, num_results=10):
        """
        구글 검색을 수행하는 함수 (Google Custom Search API 사용)
        query: 검색할 키워드 (예: "머신러닝")
        num_results: 가져올 결과 개수 (기본값: 10개, 최대 10개까지 가능)
        """
        try:  # 오류 처리를 위한 try 블록
            # 결과를 저장할 빈 리스트 만들기
            results = []
            
            # Google API 키나 검색엔진 ID가 설정되지 않은 경우 검사
            if not self.google_api_key or not self.google_cse_id:
                print("Google API 키 또는 CSE ID가 설정되지 않았습니다.")
                return []  # 빈 리스트 반환
            
            # Google Custom Search API의 인터넷 주소
            url = "https://www.googleapis.com/customsearch/v1"
            
            # Google API는 한 번에 최대 10개의 결과만 반환할 수 있음
            max_per_request = min(10, num_results)
            
            # Google API에 보낼 검색 조건들
            params = {
                "key": self.google_api_key,    # Google API 키 (인증용)
                "cx": self.google_cse_id,      # 커스텀 검색엔진 ID
                "q": query,                    # 검색할 키워드
                "num": max_per_request         # 가져올 결과 개수
            }
            
            # Google API에 검색 요청 보내기
            response = requests.get(url, params=params)
            response.raise_for_status()  # 요청 성공 여부 확인
            
            # Google에서 받은 응답을 JSON으로 변환
            data = response.json()
            
            # Google 검색 결과를 하나씩 처리
            for item in data.get('items', []):
                # 각 검색 결과를 우리가 원하는 형태로 변환
                results.append({
                    "title": item.get('title', '')[:100],      # 제목 (100자로 제한)
                    "content": item.get('snippet', '')[:200],  # 내용 요약 (200자로 제한)
                    "url": item.get('link', ''),               # 웹페이지 링크
                    "source": "구글 검색"                       # 검색 소스 표시
                })
            
            return results  # 처리된 구글 검색 결과 반환
            
        except requests.exceptions.HTTPError as e:  # HTTP 오류 처리
            # 403 오류는 API 할당량 초과나 인증 실패를 의미
            if e.response.status_code == 403:
                print("구글 API 할당량이 초과되었거나 API 키가 유효하지 않습니다.")
            else:
                print(f"구글 검색 HTTP 오류: {e}")
            return []  # 빈 리스트 반환
        except Exception as e:  # 기타 모든 오류 처리
            print(f"구글 검색 오류: {e}")
            return []  # 빈 리스트 반환
    
    def _clean_html(self, text):
        """
        HTML 태그를 제거하는 도우미 함수
        text: 처리할 텍스트 (HTML 태그가 포함되어 있을 수 있음)
        
        HTML 태그란? <b>굵은글씨</b> 같은 웹페이지에서 사용하는 태그들
        우리는 순수한 텍스트만 필요하므로 이런 태그들을 제거함
        """
        # 텍스트가 없거나 빈 문자열이면 빈 문자열 반환
        if not text:
            return ""
        
        # 정규표현식을 사용해서 HTML 태그 제거
        # 정규표현식은 텍스트 패턴을 찾는 도구 (여기서는 <...> 형태의 태그를 찾음)
        import re  # 정규표현식 라이브러리
        clean = re.compile('<.*?>')  # <로 시작해서 >로 끝나는 패턴을 찾는 규칙 만들기
        return re.sub(clean, '', text)  # 찾은 패턴들을 빈 문자열로 바꿔서 제거
    
    def integrated_search(self, query, 
                         enable_blog=True, 
                         enable_news=True, 
                         enable_google=True,
                         results_per_source=10):
        """
        여러 사이트를 한 번에 검색하는 통합 검색 함수
        
        매개변수 설명:
            query (str): 검색할 키워드 (예: "파이썬 프로그래밍")
            enable_blog (bool): 네이버 블로그 검색을 할지 말지 (True=검색함, False=안함)
            enable_news (bool): 네이버 뉴스 검색을 할지 말지 (True=검색함, False=안함)  
            enable_google (bool): 구글 검색을 할지 말지 (True=검색함, False=안함)
            results_per_source (int): 각 사이트에서 몇 개씩 가져올지 (기본값: 10개)
        
        반환값:
            dict: 모든 검색 결과를 담은 사전(딕셔너리) 형태의 데이터
        """
        
        # 모든 검색 결과를 담을 큰 그릇 만들기
        all_results = {
            "query": query,           # 검색한 키워드 저장
            "results": [],            # 모든 검색 결과들이 들어갈 리스트
            "summary": {              # 검색 결과 요약 정보
                "total_results": 0,   # 총 몇 개의 결과를 찾았는지
                "sources_used": []    # 어떤 사이트들을 검색했는지
            }
        }
        
        # 사용자에게 검색 시작을 알리는 메시지 출력
        print(f"'{query}' 검색을 시작합니다...")
        
        # 네이버 블로그 검색 (enable_blog가 True일 때만 실행)
        if enable_blog:
            print("네이버 블로그 검색 중...")  # 진행상황 알림
            # 네이버 블로그에서 검색 결과 가져오기
            blog_results = self.search_naver_blog(query, results_per_source)
            # 가져온 결과들을 전체 결과 리스트에 추가
            all_results["results"].extend(blog_results)
            # 사용한 검색 소스 목록에 "네이버 블로그" 추가
            all_results["summary"]["sources_used"].append("네이버 블로그")
            print(f"네이버 블로그 결과: {len(blog_results)}개")  # 결과 개수 출력
        
        # 네이버 뉴스 검색 (enable_news가 True일 때만 실행)
        if enable_news:
            print("네이버 뉴스 검색 중...")  # 진행상황 알림
            # 네이버 뉴스에서 검색 결과 가져오기
            news_results = self.search_naver_news(query, results_per_source)
            # 가져온 결과들을 전체 결과 리스트에 추가
            all_results["results"].extend(news_results)
            # 사용한 검색 소스 목록에 "네이버 뉴스" 추가
            all_results["summary"]["sources_used"].append("네이버 뉴스")
            print(f"네이버 뉴스 결과: {len(news_results)}개")  # 결과 개수 출력
        
        # 구글 검색 (enable_google이 True일 때만 실행)
        if enable_google:
            print("구글 검색 중...")  # 진행상황 알림
            # 구글에서 검색 결과 가져오기
            google_results = self.search_google(query, results_per_source)
            # 가져온 결과들을 전체 결과 리스트에 추가
            all_results["results"].extend(google_results)
            # 사용한 검색 소스 목록에 "구글 검색" 추가
            all_results["summary"]["sources_used"].append("구글 검색")
            print(f"구글 검색 결과: {len(google_results)}개")  # 결과 개수 출력
        
        # 총 검색 결과 개수 계산하기
        # len()은 리스트의 길이(항목 개수)를 알려주는 함수
        total = len(all_results["results"])
        all_results["summary"]["total_results"] = total
        
        # 검색 완료 메시지 출력
        print(f"\n검색 완료! 총 {total}개의 결과를 찾았습니다.")
        
        # 모든 검색 결과를 담은 딕셔너리 반환
        return all_results

# 이 코드가 직접 실행될 때만 아래 코드가 작동함 (다른 파일에서 import 했을 때는 실행 안됨)
if __name__ == "__main__":
    # SearchManager 클래스의 인스턴스(실제 객체) 만들기
    # 클래스는 설계도이고, 인스턴스는 설계도로 만든 실제 물건
    search_manager = SearchManager()
    
    # 통합 검색 실행 (모든 검색 기능을 사용)
    results = search_manager.integrated_search(
        query="AI AGENT",    # 검색할 키워드
        enable_blog=True,            # 네이버 블로그 검색 켜기
        enable_news=True,            # 네이버 뉴스 검색 켜기
        enable_google=True,          # 구글 검색 켜기
        results_per_source=5         # 각 사이트에서 5개씩 가져오기
    )
    
    # 검색 결과를 JSON 파일로 저장하기
    # JSON 파일은 데이터를 저장하는 파일 형식 중 하나
    with open("search_results.json", "w", encoding="utf-8") as f:
        # json.dump()는 파이썬 데이터를 JSON 파일로 저장하는 함수
        # ensure_ascii=False: 한글이 깨지지 않게 설정
        # indent=2: 읽기 쉽게 들여쓰기 적용
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    # 검색 결과 요약을 화면에 출력
    print(f"\n=== 검색 결과 요약 ===")
    print(f"검색어: {results['query']}")                                    # 검색한 키워드 출력
    print(f"사용된 소스: {', '.join(results['summary']['sources_used'])}")  # 검색한 사이트들 출력
    print(f"총 결과 수: {results['summary']['total_results']}")            # 전체 결과 개수 출력
    
    # 검색 결과 일부를 미리보기로 보여주기
    if results["results"]:  # 결과가 있으면 (빈 리스트가 아니면)
        print(f"\n=== 검색 결과 미리보기 ===")
        # enumerate()는 리스트의 각 항목에 번호를 매겨주는 함수
        # [:5]는 리스트의 처음 5개만 가져오기
        for i, item in enumerate(results["results"][:5]):
            print(f"\n{i+1}. [{item['source']}]")          # 결과 번호와 출처 출력
            print(f"제목: {item['title']}")                 # 제목 출력
            print(f"URL: {item['url']}")                    # 링크 주소 출력
            print(f"내용: {item['content'][:100]}...")      # 내용 일부만 출력 (100자까지)