# FastAPI를 사용한 통합 검색 API 서버
# n8n의 HTTP Request 노드에서 사용할 수 있는 REST API 제공

# 필요한 라이브러리들을 가져오기 (import)
from fastapi import FastAPI, HTTPException, Depends, Header  # FastAPI 웹 프레임워크와 HTTP 예외 처리, 의존성 주입, 헤더 처리
from fastapi.middleware.cors import CORSMiddleware  # CORS(다른 도메인에서 접근) 허용
from pydantic import BaseModel  # 데이터 검증을 위한 모델 정의
from typing import Optional, List, Annotated  # 타입 힌트용 (선택적 매개변수, 리스트 타입, 어노테이션)
import uvicorn  # FastAPI 서버 실행용

# 우리가 만든 검색 관리자 클래스 가져오기
from main import SearchManager

# FastAPI 앱 인스턴스 생성
# title, description, version은 API 문서에 표시되는 정보
app = FastAPI(
    title="통합 검색 API",
    description="네이버 블로그, 네이버 뉴스, 구글 검색을 통합해서 수행하는 API",
    version="1.0.0"
)

# CORS 설정 - 다른 도메인(n8n 등)에서 이 API에 접근할 수 있도록 허용
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 모든 도메인에서 접근 허용 (보안상 필요에 따라 제한 가능)
    allow_credentials=True,  # 쿠키나 인증 정보 포함 허용
    allow_methods=["*"],  # 모든 HTTP 메소드 허용 (GET, POST 등)
    allow_headers=["*"],  # 모든 헤더 허용
)

# SearchManager 인스턴스 생성 (앱 시작 시 한 번만 생성)
search_manager = SearchManager()

# API 보안을 위한 인증 키 설정
API_KEY = "abcd123456"  # 실제 운영 환경에서는 환경변수나 설정 파일에서 관리하는 것이 좋음

# API 키 검증 함수
def verify_api_key(key: Annotated[str | None, Header()] = None):
    """
    API 키를 검증하는 함수
    요청 헤더에서 'key'라는 이름의 헤더를 확인하고, 값이 올바른지 검증
    
    사용법:
    헤더에 key: abcd123456 을 포함해서 요청해야 함
    """
    if key is None:
        raise HTTPException(
            status_code=401,  # Unauthorized
            detail="API 키가 필요합니다. 헤더에 'key'를 포함해주세요.",
            headers={"WWW-Authenticate": "APIKey"}
        )
    
    if key != API_KEY:
        raise HTTPException(
            status_code=401,  # Unauthorized
            detail="잘못된 API 키입니다.",
            headers={"WWW-Authenticate": "APIKey"}
        )
    
    return key  # 인증 성공 시 키 값 반환

# 검색 요청 데이터 모델 정의 (들어오는 JSON 데이터의 구조를 정의)
class SearchRequest(BaseModel):
    """
    검색 요청할 때 보내야 하는 데이터 구조
    Pydantic 모델을 사용해서 자동으로 데이터 검증과 문서화가 됨
    """
    query: str  # 검색할 키워드 (필수)
    enable_blog: Optional[bool] = True  # 네이버 블로그 검색 여부 (선택, 기본값: True)
    enable_news: Optional[bool] = True  # 네이버 뉴스 검색 여부 (선택, 기본값: True)
    enable_google: Optional[bool] = True  # 구글 검색 여부 (선택, 기본값: True)
    results_per_source: Optional[int] = 10  # 각 소스별 결과 개수 (선택, 기본값: 10)

# 검색 결과 데이터 모델 정의 (API 응답 데이터의 구조를 정의)
class SearchResult(BaseModel):
    """개별 검색 결과 항목의 구조"""
    title: str  # 제목
    content: str  # 내용
    url: str  # 링크 주소
    source: str  # 검색 소스 (네이버 블로그, 네이버 뉴스, 구글 검색)

class SearchSummary(BaseModel):
    """검색 결과 요약 정보의 구조"""
    total_results: int  # 총 결과 개수
    sources_used: List[str]  # 사용된 검색 소스 목록

class SearchResponse(BaseModel):
    """전체 검색 응답 데이터의 구조"""
    query: str  # 검색한 키워드
    results: List[SearchResult]  # 검색 결과 리스트
    summary: SearchSummary  # 검색 결과 요약

# API 루트 엔드포인트 - 서버가 정상 작동하는지 확인용 (인증 불필요)
@app.get("/")
async def root():
    """
    API 서버 상태 확인용 엔드포인트
    브라우저에서 http://localhost:8000/ 으로 접속하면 이 메시지를 볼 수 있음
    이 엔드포인트는 공개 접근 가능 (API 키 불필요)
    """
    return {
        "message": "통합 검색 API 서버가 정상 작동 중입니다",
        "version": "1.0.0",
        "endpoints": {
            "search": "/search (POST) - API 키 필요",
            "docs": "/docs",
            "health": "/health"
        },
        "auth_info": {
            "required_header": "key",
            "note": "검색 API 사용 시 헤더에 'key' 값이 필요합니다"
        }
    }

# 서버 상태 확인용 엔드포인트 (인증 불필요)
@app.get("/health")
async def health_check():
    """
    서버 상태 확인용 엔드포인트
    모니터링이나 로드밸런서에서 서버가 살아있는지 확인할 때 사용
    이 엔드포인트는 공개 접근 가능 (API 키 불필요)
    """
    return {"status": "healthy", "message": "서버가 정상 작동 중입니다"}

# 메인 검색 API 엔드포인트 (API 키 필요)
@app.post("/search", response_model=SearchResponse)
async def search_integrated(request: SearchRequest, api_key: str = Depends(verify_api_key)):
    """
    통합 검색을 수행하는 메인 API 엔드포인트
    
    ⚠️ API 키 필요: 헤더에 key: abcd123456 을 포함해야 함
    
    요청 방법:
    POST /search
    Content-Type: application/json
    Headers:
        key: abcd123456
    
    요청 본문 예시:
    {
        "query": "파이썬 프로그래밍",
        "enable_blog": true,
        "enable_news": true,
        "enable_google": true,
        "results_per_source": 5
    }
    
    응답:
    {
        "query": "파이썬 프로그래밍",
        "results": [...],
        "summary": {...}
    }
    """
    try:
        # 입력값 검증
        if not request.query or request.query.strip() == "":
            raise HTTPException(
                status_code=400,  # Bad Request
                detail="검색 키워드가 비어있습니다. 'query' 필드에 검색할 키워드를 입력해주세요."
            )
        
        if request.results_per_source < 1 or request.results_per_source > 50:
            raise HTTPException(
                status_code=400,  # Bad Request
                detail="results_per_source는 1에서 50 사이의 값이어야 합니다."
            )
        
        # 모든 검색 기능이 비활성화된 경우 체크
        if not any([request.enable_blog, request.enable_news, request.enable_google]):
            raise HTTPException(
                status_code=400,  # Bad Request
                detail="최소 하나의 검색 소스는 활성화되어야 합니다."
            )
        
        # 통합 검색 실행
        search_results = search_manager.integrated_search(
            query=request.query.strip(),
            enable_blog=request.enable_blog,
            enable_news=request.enable_news,
            enable_google=request.enable_google,
            results_per_source=request.results_per_source
        )
        
        # 결과를 FastAPI 응답 모델에 맞게 변환
        response = SearchResponse(
            query=search_results["query"],
            results=[
                SearchResult(
                    title=item["title"],
                    content=item["content"],
                    url=item["url"],
                    source=item["source"]
                ) for item in search_results["results"]
            ],
            summary=SearchSummary(
                total_results=search_results["summary"]["total_results"],
                sources_used=search_results["summary"]["sources_used"]
            )
        )
        
        return response
        
    except HTTPException:
        # HTTPException은 그대로 다시 발생시킴 (위에서 정의한 에러들)
        raise
    except Exception as e:
        # 예상치 못한 오류가 발생한 경우
        raise HTTPException(
            status_code=500,  # Internal Server Error
            detail=f"서버 내부 오류가 발생했습니다: {str(e)}"
        )

# 간단한 GET 방식 검색 엔드포인트 (API 키 필요)
@app.get("/search/{query}")
async def search_simple(query: str, 
                       enable_blog: bool = True,
                       enable_news: bool = True, 
                       enable_google: bool = True,
                       results_per_source: int = 5,
                       api_key: str = Depends(verify_api_key)):
    """
    간단한 GET 방식 검색 API (테스트나 간단한 용도로 사용)
    
    ⚠️ API 키 필요: 헤더에 key: abcd123456 을 포함해야 함
    
    사용 예시:
    GET /search/파이썬프로그래밍
    Headers: key: abcd123456
    
    또는 파라미터와 함께:
    GET /search/AI기술?enable_blog=true&enable_news=false&results_per_source=3
    Headers: key: abcd123456
    """
    try:
        # SearchRequest 객체로 변환해서 메인 검색 함수 호출
        request = SearchRequest(
            query=query,
            enable_blog=enable_blog,
            enable_news=enable_news,
            enable_google=enable_google,
            results_per_source=results_per_source
        )
        
        return await search_integrated(request)
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"검색 중 오류가 발생했습니다: {str(e)}"
        )

# API 키 정보 확인 엔드포인트 (API 키 필요)
@app.get("/api-status")
async def api_status(api_key: str = Depends(verify_api_key)):
    """
    설정된 API 키들의 상태를 확인하는 엔드포인트
    실제 키 값은 보안상 노출하지 않고, 설정 여부만 확인
    
    ⚠️ API 키 필요: 헤더에 key: abcd123456 을 포함해야 함
    """
    return {
        "naver_api": {
            "client_id_configured": bool(search_manager.naver_client_id),
            "client_secret_configured": bool(search_manager.naver_client_secret)
        },
        "google_api": {
            "api_key_configured": bool(search_manager.google_api_key),
            "cse_id_configured": bool(search_manager.google_cse_id)
        },
        "authentication": {
            "status": "인증됨",
            "message": "올바른 API 키로 인증되었습니다"
        }
    }

# 서버 실행 부분 (이 파일을 직접 실행했을 때만 작동)
if __name__ == "__main__":
    print("=== 통합 검색 API 서버 시작 ===")
    print("서버 주소: http://localhost:8000")
    print("API 문서: http://localhost:8000/docs")
    print("서버를 중지하려면 Ctrl+C를 누르세요")
    print("")
    
    # uvicorn으로 FastAPI 서버 실행
    # host="0.0.0.0": 모든 네트워크 인터페이스에서 접근 허용
    # port=8000: 8000번 포트 사용
    # reload=True: 코드 변경 시 자동으로 서버 재시작 (개발용)
    uvicorn.run(
        "app:app",  # "파일명:앱변수명"
        host="0.0.0.0", 
        port=8000, 
        reload=True
    )
