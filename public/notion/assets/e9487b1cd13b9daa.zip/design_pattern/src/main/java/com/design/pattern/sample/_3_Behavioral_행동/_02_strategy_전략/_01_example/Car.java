package com.design.pattern.sample._3_Behavioral_행동._02_strategy_전략._01_example;

/**
 * 구체적인 전략 1: 자동차
 * travel() 메서드를 구현하여, 지정된 출발지와 목적지에 대해 특정 운송 수단을 사용하는 방식으로 동작
 * */
public class Car implements TransportStrategy {
    @Override
    public void travel(String start, String destination) {
        System.out.println(start + "에서 " + destination + "로 주행합니다.");
    }
}