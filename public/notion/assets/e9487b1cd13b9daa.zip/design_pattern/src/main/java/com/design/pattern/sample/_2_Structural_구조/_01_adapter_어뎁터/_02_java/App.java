package com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._02_java;

import org.springframework.util.ResourceUtils;

import java.io.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class App {

    public static void main(String[] args) throws FileNotFoundException {
        List<String> strings = Arrays.asList("a", "b", "c");
        // java 1부터 사용되었던 구버전 Collection인 Enumeration에서
        Enumeration<String> enumeration = Collections.enumeration(strings);
        // java 14 이후 제공된 Enumeration -> List를 통해 변환하는 adapter 역할
        List<String> list = Collections.list(enumeration);
        list.forEach(System.out::println);

        // io
        File file = ResourceUtils.getFile("classpath:input.txt");
        try(// file을 bit로 직렬화하여 stream으로 읽어들인 후
            InputStream is = new FileInputStream(file);
            // bit 기반 stream을 향상된 문자 기반 stream으로 변환하여 adapter 역할
            InputStreamReader isr = new InputStreamReader(is);
            // 문자 기반 stream에서 버퍼 기능을 추가한 bufferdReader로 라인 단위로 파일을 읽게 함
            BufferedReader reader = new BufferedReader(isr)
        ) {
            while (reader.ready()) {
                System.out.println(reader.readLine()); // 라인 단위로 읽기
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
