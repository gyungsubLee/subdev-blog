package com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.product;

import lombok.*;


/**
 * 제품
 * 제품의 공통되는 기능을 정의
 */
@Getter
public abstract class Transport {

    private String name;
    private String color;
    private String logo;

    public void setDefaultOption(String name, String color, String logo) {
        this.name = name;
        this.color = color;
        this.logo = logo;
    }
}
