package com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._03_spring;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.HandlerAdapter;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

public class App {

    public static void main(String[] args) {
//     1. 요청을 보내면 DispatcherServlet이 request를 받는다.
//     2. DispatcherServlet은 적절한 controller를 선택하는 일을 HandlerMapping에게 요청한다.
//     3. HandlerMapping은 적합한 controller를 선택한다.
//     4. DispatcherServlet은 선택된 controller의 비즈니스 로직 실행 작업을 HandlerAdapter에게 위임한다.
//     5. HandlerAdpater가 controller의 비즈니스 로직을 호출하고 결과를 ModelAndView 객체에 담아서 DispatcherServlet이 에게 return한다.
       DispatcherServlet dispatcherServlet = new DispatcherServlet();

//     @GetMapping만으로 Controller에 메소드를 찾을 수 있었던 것은 Spring 내 RequestMappingHandlerAdapter가 어뎁터 역할을 수행하기 때문
       HandlerAdapter handlerAdapter = new RequestMappingHandlerAdapter();
    }

    @Controller
    public class SpringController {

        @GetMapping
        public String index() {
            return "index";
        }
    }
}
