package com.design.pattern.sample._3_Behavioral_행동._01_template_템플릿._03_spring;

import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

// WebSecurityConfigureAdapter 클래스를 상속 하고 configure() 메서드를 오버라이드하면,
// 스프링 프레임워크의 Config 로직의 거대한 알고리즘 중 일부를 구현하게 되는 것이다.
public class App {

    public static void main(String[] args) {
        // JdbcTemplate은 execute와 같은 템플릿 메소드를 제공하여
        // Connection 생성, SQL 실행, 예외 처리, Connection 해제 등의 반복적 작업을 감추고
        // SQL 문자열과 ResultSet 처리 로직은 클라이언트가 제공.
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.execute("select * from db");

        // RestTemplate은 exchange와 같은 템플릿 메소드를 제공하여
        // HTTP 요청 생성, 전송, 응답 파싱 과정은 감추고
        // 요청 URL, 헤더, 메서드, 데이터 등 가변적인 입력을 제공
        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.set("X-COM-PERSIST", "NO");
        headers.set("X-COM-LOCATION", "USA");

        HttpEntity<String> entity = new HttpEntity<String>(headers);
        ResponseEntity<String> responseEntity = restTemplate
                .exchange("http://localhost:8080/users", HttpMethod.GET, entity, String.class);
    }
}
