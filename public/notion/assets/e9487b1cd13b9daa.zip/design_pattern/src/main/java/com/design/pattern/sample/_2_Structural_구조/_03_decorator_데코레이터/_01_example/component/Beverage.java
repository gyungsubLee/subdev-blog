package com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.component;

/**
 *  컴포넌트 인터페이스
 *  기본 동작(설명과 가격)을 정의
 *  */
public interface Beverage {
    String getDescription();
    double getCost();
}