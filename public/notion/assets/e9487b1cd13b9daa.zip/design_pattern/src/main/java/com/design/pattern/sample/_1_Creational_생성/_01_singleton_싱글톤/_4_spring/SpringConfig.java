package com.design.pattern.sample._1_Creational_생성._01_singleton_싱글톤._4_spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {

    @Bean
    public String initConfig() {
        return "initConfig";
    }

}
