package com.design.pattern.sample._1_Creational_생성._03_builder_빌더._01_example;

/**
 * lombock에서 제공하는 builder 패턴을 구현한 코드입니다.
 * 해당 방식으로 객체를 생성 시
 * Car 클래스의 필드들이 final로 선언되어 있어 객체 생성 후 변경이 불가능합니다.
 * 원하는 속성만 선택적으로 설정할 수 있습니다.
 * 어떤 필드에 어떤 값이 설정되는지 명확히 알 수 있습니다.
* */
// @Builder
public class Car {

    private String color;
    private String engine;
    private int wheelSize;
    private boolean sunroof;
    private boolean gps;

    private Car(CarBuilder builder) {
        this.color = builder.color;
        this.engine = builder.engine;
        this.wheelSize = builder.wheelSize;
        this.sunroof = builder.sunroof;
        this.gps = builder.gps;
    }

    // Car와 동일한 형태의 CarBuilder를 inner class로 생성
    public static class CarBuilder {
        private String color;
        private String engine;
        private int wheelSize;
        private boolean sunroof;
        private boolean gps;

        public CarBuilder color(String color) {
            this.color = color;
            // 자기 자신을 반환함으로써 method chain 가능
            return this;
        }

        public CarBuilder engine(String engine) {
            this.engine = engine;
            return this;
        }

        public CarBuilder wheelSize(int wheelSize) {
            this.wheelSize = wheelSize;
            return this;
        }

        public CarBuilder sunroof(boolean sunroof) {
            this.sunroof = sunroof;
            return this;
        }

        public CarBuilder gps(boolean gps) {
            this.gps = gps;
            return this;
        }

        // CarBuilder에 build 메소드 호출 시 실제 객체를 빌드하여 생성
        public Car build() {
            return new Car(this);
        }
    }

    // CarBuilder에 builder 메소드 호출 시 CarBuilder를 생성하고 실제 객체를 조립
    public static CarBuilder builder() {
        return new CarBuilder();
    }
}