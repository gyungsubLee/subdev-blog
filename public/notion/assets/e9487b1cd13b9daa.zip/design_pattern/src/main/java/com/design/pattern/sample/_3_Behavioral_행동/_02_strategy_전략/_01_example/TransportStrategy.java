package com.design.pattern.sample._3_Behavioral_행동._02_strategy_전략._01_example;

/**
 * 전략 인터페이스: 운송 수단
 * TransportStrategy 인터페이스는 여행 전략을 정의합니다. 각 전략은 travel() 메서드를 구현
 * */
public interface TransportStrategy {
    void travel(String start, String destination);
}