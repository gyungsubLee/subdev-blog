package com.design.pattern.sample._1_Creational_생성._01_singleton_싱글톤._1_case;

/**
 * case 1 : private 생성자와 public static 메소드를 사용하는 방법
 */
public class Sample {

    private static Sample instance;

    private Sample() { }

    public static Sample getInstance() {
        if (instance == null) {
            instance = new Sample();
        }

        return instance;
    }

}