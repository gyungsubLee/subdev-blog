package com.design.pattern.sample._1_Creational_생성._01_singleton_싱글톤._3_java;

public class Example {

    public static void main(String[] args) {
        // Runtime 객체는 시스템이 실행될 때 실행환경을 관리하기 위한 객체임으로 하나만 존재
        Runtime runtime = Runtime.getRuntime();
        System.out.println(runtime.maxMemory());
        System.out.println(runtime.freeMemory());
    }
}
