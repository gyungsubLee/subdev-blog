package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._02_example;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * 동적 프록시
 * InvocationHandler를 통해 동적으로 proxy 객체를 생성
 * invoke() 메서드가 호출될 때 RealSubject 클래스를 동적으로 읽어들여 조작
 * */
public class ProxyHandler implements InvocationHandler {

    private Object target;

    public ProxyHandler(Object target) {
        this.target = target;
    }
    
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println(target.getClass().getSimpleName() + " 클래스에 " + method.getName() + " 호출 전");
        Object result = method.invoke(target, args);
        System.out.println(target.getClass().getSimpleName() + " 클래스에 " + method.getName() + " 호출 후");
        return result;
    }
}