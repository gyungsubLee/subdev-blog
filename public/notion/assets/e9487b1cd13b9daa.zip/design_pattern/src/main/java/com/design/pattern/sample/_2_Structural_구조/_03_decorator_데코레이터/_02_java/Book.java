package com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._02_java;

public class Book {
    private String title;
}