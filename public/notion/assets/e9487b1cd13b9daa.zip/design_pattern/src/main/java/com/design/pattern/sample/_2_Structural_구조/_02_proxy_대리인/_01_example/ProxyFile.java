package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._01_example;

/**
 * 가상 프록시
 * RealSubjcet와 동일한 행위를 수행하게 Subject의 행위를 구현하지만 결과값을 바꾸면 안됨
 * display() 메서드가 호출될 때 실제 파일 객체를 로드하는 '가상 프록시'
 * */
public class ProxyFile implements File {
    private java.io.File file;
    private RealFile realImage;

    public ProxyFile(java.io.File file) {
        this.file = file;
    }

    private void loadImage() {
        if (realImage == null) {
            realImage = new RealFile(file); // 지연하여 생성함으로 '지연 로딩'
        }
    }

    @Override
    public void display() {
        loadImage();
        realImage.display();
    }
}