package com.design.pattern.sample._3_Behavioral_행동._02_strategy_전략._02_java;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class App {

    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();
        numbers.add(10);
        numbers.add(5);

        // Collections.sort()가 Context(실행 환경이나 작업을 관리하는 클래스) 역할로
        // 정렬 작업을 수행하지만, 실제로 어떤 정렬 방식(전략)을 사용할지는 외부에서 제공받음.
        Collections.sort(
                numbers,
                // Comparator가 전략 역할로
                // Comparator 인터페이스를 구현하여 특정 정렬 방식을 정의하는 클래스.
                // 예: Comparator.naturalOrder() 또는 Comparator.reverseOrder().
                Comparator.naturalOrder()
        );

        System.out.println(numbers);
    }
}
