package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._01_example;

/**
 * RealSubjcet
 * 실제 파일를 로딩하고 표시하는 객체
 * */
public class RealFile implements File {
    private java.io.File file;

    public RealFile(java.io.File file) {
        this.file = file;
        loadImage();
    }

    private void loadImage() {
        System.out.println("실제 로드할 이미지: " + file.getName());
    }

    @Override
    public void display() {
        System.out.println("파일명 출력: " + file.getName());
    }
}