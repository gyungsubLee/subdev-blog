package com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example;

import com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adaptee.MemberService;
import com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adapter.UserDetailsServiceImpl;
import com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adapter.UserDetailsService;
import com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.client.UserClient;

public class App {

    public static void main(String[] args) {
        // adaptee
        MemberService memberService = new MemberService();

        // adapter를 주입받은 client interface
        UserDetailsService userDetailsService = new UserDetailsServiceImpl(memberService);

        // client
        UserClient client = new UserClient(userDetailsService);
        String login = client.login("leeth", "1q2w3e4r");
        System.out.println("로그인 사용자 == " + login);
    }
}
