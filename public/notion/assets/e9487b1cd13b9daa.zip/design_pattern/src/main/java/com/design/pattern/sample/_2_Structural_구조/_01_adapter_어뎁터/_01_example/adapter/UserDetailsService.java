package com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adapter;

/**
 * 클라이언트 인터페이스
 * 클라이언트가 호출하는 메소드를 가지며 클라이언트와 adapter와 중개
 * Spring Securiy 모듈에선 bean으로 등록되어 관리
 * */
public interface UserDetailsService {

    UserDetails loadUserByUsername(String username);

}
