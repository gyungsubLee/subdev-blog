package com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._02_spring;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

/**
 * 이벤트 퍼블리셔
 * Spring의 ApplicationEventPublisher를 사용하여 이벤트를 발생시키는 역할
 * */
@Component
public class MyRunner implements ApplicationRunner {

    private ApplicationEventPublisher publisher;

    public MyRunner(ApplicationEventPublisher publisher) {
        this.publisher = publisher;
    }

    // 1. ApplicationEventPublisher를 사용하여 새로운 MyEvent를 호출하여 이벤트를 생성
    @Override
    public void run(ApplicationArguments args) throws Exception {
        publisher.publishEvent(new MyEvent("새로운 My Event 실행!!"));
    }
}
