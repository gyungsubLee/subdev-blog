package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._02_example;

/**
 * Subject interface
 * RealSubject(RealService)와 Proxy(DynamicProxyHandler)가 동일한 행위를 하도록 구현
 */
public interface Subject {
    void doSomething();
}