package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._02_spring;

import org.springframework.stereotype.Service;

/**
* RealSubject로 실제 동작할 객체
* */
@Service
public class StudyService {

    public void Study() {
        System.out.println("Spring 공부해 보아요!");
    }

}
