package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._02_spring;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
* Spring AOP는 관심 대상(StudyService)이 생성되어 실행될 때 proxy 객체를 생성하여 동작을 확장 시키는 '동적 프록시 패턴'을 적용
* */
@Slf4j
@Aspect
@Component
public class StudyAspect {

    @Around("bean(studyService)")
    public void pointcut(ProceedingJoinPoint point) throws Throwable {
        System.out.println("메소드 실행 전");
        point.proceed();
        System.out.println("메소드 실행 후");
    }
}
