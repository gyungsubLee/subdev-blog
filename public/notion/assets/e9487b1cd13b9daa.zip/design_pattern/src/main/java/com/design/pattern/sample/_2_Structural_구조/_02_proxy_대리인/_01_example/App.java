package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._01_example;

import org.springframework.util.ResourceUtils;

import java.io.FileNotFoundException;

public class App {
    public static void main(String[] args) throws FileNotFoundException {
        // 프록시 객체 사용
        File file = new ProxyFile(ResourceUtils.getFile("classpath:input.txt"));

        // 이미지가 처음 로드될 때만 실제 객체가 로드됨
        file.display();
    }
}