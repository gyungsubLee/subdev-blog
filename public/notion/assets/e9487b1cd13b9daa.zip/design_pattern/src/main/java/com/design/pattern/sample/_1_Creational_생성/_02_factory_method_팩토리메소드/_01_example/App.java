package com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example;

import com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.factory.BusFactory;
import com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.factory.TransportFactory;
import com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.factory.VehicleFactory;

// 클라이언트 클래스
public class App {

    public static void main(String[] args) {
        TransportFactory vehicle = new VehicleFactory();
        System.out.println(
                vehicle.order("빠스", "blue", "volvo")
        );

        TransportFactory bus = new BusFactory();
        System.out.println(
                bus.order("따릉이", "silver", "삼천리")
        );
    }

}
