package com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example;

import com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.component.Beverage;
import com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.component.Espresso;
import com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.decorator.Milk;
import com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.decorator.Sugar;

public class App {
    public static void main(String[] args) {
        Beverage beverage = new Espresso();  // 기본 음료
        System.out.println(beverage.getDescription() + " -> ₩" + beverage.getCost());

        // Milk 추가
        beverage = new Milk(beverage);
        System.out.println(beverage.getDescription() + " -> ₩" + beverage.getCost());

        // Sugar 추가
        beverage = new Sugar(beverage);
        System.out.println(beverage.getDescription() + " -> ₩" + beverage.getCost());
    }
}