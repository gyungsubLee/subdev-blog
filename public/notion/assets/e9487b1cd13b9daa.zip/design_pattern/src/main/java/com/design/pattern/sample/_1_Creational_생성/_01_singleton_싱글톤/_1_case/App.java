package com.design.pattern.sample._1_Creational_생성._01_singleton_싱글톤._1_case;

import java.io.*;

public class App {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        // 시스템에 하나의 인스턴스만 존재
        Sample instance1 = Sample.getInstance();
        Sample instance2 = Sample.getInstance();

        System.out.println(instance1 == instance2); // true
    }

}
