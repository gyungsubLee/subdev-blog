package com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example;


import com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example.observer.Investor;
import com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example.observer.Trader;
import com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example.subject.Stock;

public class App {
    public static void main(String[] args) {
        // 주식 객체 생성
        Stock stock = new Stock("SAMSUNG", 49.0);

        // 투자자 객체 생성
        Investor investor = new Investor("투자자");
        Trader trader = new Trader("트레이더");

        // 투자자들 등록
        stock.registerObserver(investor);
        stock.registerObserver(trader);

        // 주식 가격 변경
        System.out.println("주식 가격을 변경합니다...");
        stock.setPrice(51.0);  // 가격 변경

        // 또 다른 가격 변경
        System.out.println("주식 가격을 다시 변경합니다...");
        stock.setPrice(48.0);  // 가격 변경

        // 구독자 제거 후 가격 변경
        stock.removeObserver(trader);  // 트레이더 구독 취소
        System.out.println("트레이더 구독 취소 후 가격 변경...");
        stock.setPrice(45.0);  // 가격 변경
    }
}