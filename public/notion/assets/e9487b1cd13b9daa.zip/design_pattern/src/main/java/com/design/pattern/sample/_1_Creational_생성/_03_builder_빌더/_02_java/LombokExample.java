package com.design.pattern.sample._1_Creational_생성._03_builder_빌더._02_java;

import lombok.Builder;
import lombok.ToString;

@Builder
@ToString
public class LombokExample {

    private final String color;
    private final String engine;
    private final int wheelSize;


}
