package com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adapter;

import com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adaptee.MemberService;
import lombok.RequiredArgsConstructor;

/**
 * adapter 클래스
 * 클라이언트(Controller - 실제)와 adaptee(MemberService)를 중개하는 역할
 * */
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final MemberService memberService;

    @Override
    public UserDetails loadUserByUsername(String username) {
        return new UserDetailsImpl(memberService.findMemberByUsername(username));
    }
}
