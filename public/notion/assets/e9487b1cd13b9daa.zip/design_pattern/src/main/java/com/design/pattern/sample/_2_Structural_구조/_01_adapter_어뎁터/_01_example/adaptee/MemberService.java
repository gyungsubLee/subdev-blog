package com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adaptee;

/**
 * adaptee 클래스
 * 실제 서비스에 도메인으로 사용하는 entity에 비즈니스 로직이 분리된 클래스
 * */
public class MemberService {

    public Member findMemberByUsername(String username) {
        Member member = new Member();
        member.initTempMember(username);
        return member;
    }
}
