package com.design.pattern.sample._3_Behavioral_행동._02_strategy_전략._03_spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.support.JdbcTransactionManager;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

public class App {

    public static void main(String[] args) {
        // spring에 거의 모든 spring에 interface가 전략 패턴이라고 봐도 무방할 정도로 굉장히 많은 전략 패턴이 숨이 있습니다.
        // 아래에 보이는 context와 transactionManager 들도 각각 설정에 따라 spring bean으로 등록하고 주입하여 사용할 수 있습니다.
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext();
        ApplicationContext applicationContext1 = new FileSystemXmlApplicationContext();
        ApplicationContext applicationContext2 = new AnnotationConfigApplicationContext();

        PlatformTransactionManager platformTransactionManager = new JdbcTransactionManager();
        PlatformTransactionManager platformTransactionManager1 = new HibernateTransactionManager();
        PlatformTransactionManager platformTransactionManager2 = new JpaTransactionManager();
    }
}
