package com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.decorator;

import com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.component.Beverage;

/**
 *  구체적 데코레이터
 *  실제로 음료에 추가적인 행동(설명과 가격)을 추가
 *  */
public class Sugar extends BeverageDecorator {
    public Sugar(Beverage beverage) {
        super(beverage);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + 설탕 추가";
    }

    @Override
    public double getCost() {
        return super.getCost() + 100.0;
    }
}