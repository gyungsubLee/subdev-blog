package com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example.subject;

import com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example.observer.Observer;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 *  Subject : 주식
 *  주식 가격을 관리하는 클래스
 *  가격이 변경되면 notifyObservers() 메서드를 호출하여 모든 구독자에게 알림을 보냅니다.
 *  구독자는 setPrice() 메서드를 통해 가격을 변경할 수 있습니다.
 *  */
@Getter
public class Stock implements Subject {
    private List<Observer> observers;
    private String stockSymbol;
    private double price;

    public Stock(String stockSymbol, double price) {
        observers = new ArrayList<>();
        this.stockSymbol = stockSymbol;
        this.price = price;
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    // 구독자들에게 알림을 보내는 메소드
    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(stockSymbol, price);
        }
    }

    // 주식 가격을 변경하는 메서드
    public void setPrice(double price) {
        this.price = price;
        notifyObservers(); // 가격이 변경되면 구독자에게 알림
    }
}