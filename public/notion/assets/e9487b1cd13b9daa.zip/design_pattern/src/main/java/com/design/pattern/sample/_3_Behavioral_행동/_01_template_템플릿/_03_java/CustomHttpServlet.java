package com.design.pattern.sample._3_Behavioral_행동._01_template_템플릿._03_java;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * HttpServlet은 HTTP 요청 처리의 기본적인 흐름(템플릿 메소드)을 정의하여 감춰져 있고,
 * 개발자가 필요한 메서드(doGet, doPost 등)를 오버라이드하여 구현하도록 설계되어 있음.
 */
public class CustomHttpServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        System.out.println("get 방식으로 호출되었습니다.");
        super.doGet(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        System.out.println("post 방식으로 호출되었습니다.");
        super.doPost(req, res);
    }
}
