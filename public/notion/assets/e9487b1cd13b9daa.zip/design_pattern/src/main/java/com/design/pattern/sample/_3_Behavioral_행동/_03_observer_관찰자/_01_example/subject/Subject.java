package com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example.subject;

import com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example.observer.Observer;

/**
 * Subject 인터페이스
 * 상태를 변경하는 객체가 구현해야 하는 인터페이스
 * 구독자 관리(registerObserver(), removeObserver()) 및 알림 발송(notifyObservers()) 메서드를 제공합니다.
 * */
// Subject 인터페이스:
public interface Subject {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers();
}