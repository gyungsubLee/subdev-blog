package com.design.pattern.sample._1_Creational_생성._03_builder_빌더._02_java;

import java.util.stream.Stream;

public class App {

    public static void main(String[] args) {
        LombokExample car = LombokExample.builder()
                .color("black")
                .engine("V8")
                .wheelSize(3)
                .build();

        System.out.println(car.toString());

        Stream.builder()
                .add("안녕하세요 ~")
                .add("스파르타 화이팅!!")
                .build()
                .forEach(System.out::println);


        String result = new StringBuilder()
                .append("안녕하세요~")
                .append("스파르타 화이팅!!")
                .toString();

        System.out.println(result);
    }
}
