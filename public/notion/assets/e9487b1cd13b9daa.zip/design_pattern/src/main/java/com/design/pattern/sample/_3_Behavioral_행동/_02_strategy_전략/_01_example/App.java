package com.design.pattern.sample._3_Behavioral_행동._02_strategy_전략._01_example;

public class App {
    public static void main(String[] args) {
        // 여행 컨텍스트 생성
        TravelContext context = new TravelContext();

        // 자동차 여행 전략
        context.setTransportStrategy(new Car());
        context.executeTravel("서울", "부산");

        // 기차 여행 전략
        context.setTransportStrategy(new Train());
        context.executeTravel("부산", "인천");

        // 비행기 여행 전략
        context.setTransportStrategy(new Airplane());
        context.executeTravel("인천", "제주");
    }
}