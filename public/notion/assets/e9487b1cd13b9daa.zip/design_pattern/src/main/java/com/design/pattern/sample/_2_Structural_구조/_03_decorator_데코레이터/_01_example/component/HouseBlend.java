package com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.component;

/**
 *  구체적 컴포넌트
 *  기본 음료를 정의합니다.
 *  */
public class HouseBlend implements Beverage {
    @Override
    public String getDescription() {
        return "핸드블렌드 커피";
    }

    @Override
    public double getCost() {
        return 5500.0;
    }
}