package com.design.pattern.sample._1_Creational_생성._03_builder_빌더._01_example;

public class App {

    public static void main(String[] args) {
        Car car = Car.builder()
                .color("Red")
                .engine("V8")
                .wheelSize(18)
                .sunroof(true)
                .gps(false)
                .build();
    }
}
