package com.design.pattern.sample._3_Behavioral_행동._01_template_템플릿._01_example;

public class App {
    public static void main(String[] args) {
        // 네이버 결제
        PaymentProcessor creditCardProcessor = new NaverPayProcessor();
        creditCardProcessor.processPayment(50000); // 50,000원 결제
        
        // 토스 결제
        PaymentProcessor payPalProcessor = new TossPayProcessor();
        payPalProcessor.processPayment(30000); // 30,000원 결제
    }
}