package com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._02_spring;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
/**
 * 이벤트 리스너
 * 특정 이벤트를 처리하는 전략 역할
 * 이벤트가 발생하면 호출되어 실행되는 구체적인 전략
 * */
@Component
public class MyEventListener {

    // EventListener로 MyEvent를 등록해 두면
    // ApplicationEventPublisher에 의해 신규 MyEvent가 생성되었을 때
    // EventListener 아래 구현한 로직이 수행 됨
    @EventListener(MyEvent.class)
    public void onApplicationEvent(MyEvent event) {
        System.out.println(event.getMessage());
    }
}
