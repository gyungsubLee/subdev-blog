package com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.factory;

import com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.product.Transport;

// 생성자 인터페이스
public interface TransportFactory {

    // 팩토리 메소드 : 제품을 생성할 때 전, 후처리가 가능
    default Transport order(String name, String color, String logo) {
        validate(name, color, logo);
        prepareFor(name);
        Transport transport = create();
        transport.setDefaultOption(name, color, logo);
        complete(transport);
        return transport;
    }

    Transport create();

    private void validate(String name, String color, String logo) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException(" 이름을 지어주세요.");
        }
    }

    private void prepareFor(String name) {
        System.out.println(name + " 만드는 중입니다.");
    }

    private void complete(Transport transport) {
        System.out.println(transport.getName() + "를 만들었습니다.");
    }
}
