package com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._02_java;

public class Sample {

    // static 메소드를 통해 객체 생성 방식을 제공
    public static Sample getInstance() {
        return new Sample();
    }

}