package com.design.pattern.sample._3_Behavioral_행동._02_strategy_전략._01_example;

/**
 * 컨텍스트 클래스
 * TravelContext 클래스는 실제 여행을 수행하는 클래스
 * 이 클래스는 setTransportStrategy() 메서드를 통해 운송 전략을 설정하고,
 * executeTravel() 메서드를 통해 설정된 전략을 실행합니다. 전략은 런타임에 동적으로 변경
 * */
public class TravelContext {
    private TransportStrategy transportStrategy;

    // 운송 전략을 설정하는 메서드
    public void setTransportStrategy(TransportStrategy transportStrategy) {
        this.transportStrategy = transportStrategy;
    }

    // 여행 실행 메서드
    public void executeTravel(String start, String destination) {
        if (transportStrategy == null) {
            throw new IllegalStateException("운송 수단을 선택해주세요.");
        }
        transportStrategy.travel(start, destination);
    }
}