package com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.decorator;

import com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.component.Beverage;

/**
 *  데코레이터 클래스
 *  기본 객체를 감싸 새로운 기능을 추가할 수 있도록 함
 *  */
public abstract class BeverageDecorator implements Beverage {
    protected Beverage beverage;

    public BeverageDecorator(Beverage beverage) {
        this.beverage = beverage;
    }

    @Override
    public String getDescription() {
        return beverage.getDescription();
    }

    @Override
    public double getCost() {
        return beverage.getCost();
    }
}