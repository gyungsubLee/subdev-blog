package com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.product;

/**
 * 구체적 제품
 * 제품을 재정의한 객체
 */
public class Bus extends Transport {

}
