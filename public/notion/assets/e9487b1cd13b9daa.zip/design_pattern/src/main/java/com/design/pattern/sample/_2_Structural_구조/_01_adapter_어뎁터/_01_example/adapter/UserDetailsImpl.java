package com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adapter;

import com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adaptee.Member;
import lombok.RequiredArgsConstructor;

/**
 * adapter 클래스
 * 클라이언트와 adaptee(Member)를 중개하는 역할
 * */
@RequiredArgsConstructor
public class UserDetailsImpl implements UserDetails {

    // adaptee인 member를 조합하여 사용
    private final Member member;

    @Override
    public String getUsername() {
        return member.getName();
    }

    @Override
    public String getPassword() {
        return member.getPassword();
    }
}
