package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._01_example;

/**
 * Subject interface
 * RealSubject(RealFile)와 Proxy(ProxyFile)가 동일한 행위를 하도록 구현
 */
public interface File {
    void display();
}