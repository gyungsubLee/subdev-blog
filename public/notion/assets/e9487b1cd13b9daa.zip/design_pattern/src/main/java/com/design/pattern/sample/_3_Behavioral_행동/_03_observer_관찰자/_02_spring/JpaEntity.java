package com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._02_spring;

import jakarta.persistence.EntityListeners;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
/**
 * jpa AuditingEntityListener 또한 entity의 상태가 변경되면
 * AuditingEntityListener가 entity를 관찰하다 쿼리를 데이터베이스에 전송할 때
 * @CreatedDate, @LastModifiedDate이 선언된 데이터에 값을 주입 함
 * */
@EntityListeners(AuditingEntityListener.class)
public class JpaEntity {

    @CreatedDate
    private LocalDateTime createdDate;

    @LastModifiedDate
    private LocalDateTime modifiedDate;
}
