package com.design.pattern.sample._3_Behavioral_행동._01_template_템플릿._01_example;

/**
 * 추상 템플릿
 * 결제 프로세스를 정의한 추상 템플릿으로 템플릿 메소드를 통해 전체 흐름을 제어
 * */
abstract class PaymentProcessor {
    
    // 템플릿 메서드: 결제 프로세스 전체 흐름을 제어
    // initializePayment와 generateReceipt는 모든 결제 방식에 공통적인 작업이므로 공통 메서드로 구현.
    // authenticate와 processTransaction은 결제 수단마다 다른 방식으로 처리되므로 추상 메서드로 정의.
    public final void processPayment(double amount) {
        // 1. 결제 초기화
        initializePayment();
        
        // 2. 결제 수단 인증
        authenticate();
        
        // 3. 결제 처리 (세부 구현은 하위 클래스에서)
        processTransaction(amount);
        
        // 4. 영수증 발급
        generateReceipt();
        
        System.out.println("결제가 완료되었습니다.\n");
    }
    
    // 공통 메서드: 결제 초기화
    private void initializePayment() {
        System.out.println("결제를 초기화합니다.");
    }
    
    // 공통 메서드: 영수증 발급
    private void generateReceipt() {
        System.out.println("영수증을 발급합니다.");
    }
    
    // 추상 메서드: 결제 수단 인증 (하위 클래스에서 구현)
    protected abstract void authenticate();
    
    // 추상 메서드: 결제 처리 (하위 클래스에서 구현)
    protected abstract void processTransaction(double amount);
}