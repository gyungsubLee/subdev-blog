package com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adaptee;

import lombok.Getter;

/**
 * adaptee 클래스
 * 실제 서비스에 도메인으로 사용하는 entity 클래스
 * */
@Getter
public class Member {

    private String name;

    private String password;

    private String email;

    public void initTempMember(String name) {
        this.name = name;
        this.password = "1q2w3e4r";
        this.email = "leeth@gmail.com";
    }
}
