package com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example.observer;


/**
 * 구체적 관찰자 : 트레이더
 * 주식 가격의 변화를 구독하고 있는 구체적인 옵저버 클래스
 * 가격이 변경되면 update() 메서드가 호출되어 알림을 받습니다
 * */
public class Trader implements Observer {
    private String name;

    public Trader(String name) {
        this.name = name;
    }

    @Override
    public void update(String stockSymbol, double price) {
        System.out.println(name + "님, " + stockSymbol + "의 새로운 가격은 " + price + "입니다.");
    }
}