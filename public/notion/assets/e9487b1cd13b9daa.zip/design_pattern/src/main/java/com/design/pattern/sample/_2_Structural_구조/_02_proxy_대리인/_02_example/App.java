package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._02_example;

import java.lang.reflect.Proxy;

public class App {

    public static void main(String[] args) {
        Subject realSubject = new RealSubject();

        // java reflection:
        // 구체적인 Class Type을 알지 못하더라도 해당 Class의 method, type, variable들에 접근할 수 있도록 해주는 자바 API
        // 직접 Class에 사용하는 것이 아닌 동적으로 클래스를 조작할 수 있음
        // 매우 비싼 자원이지만 자주 쓰임
        Subject proxy = (Subject) Proxy.newProxyInstance(
                Subject.class.getClassLoader(),
                new Class[] { Subject.class },
                new ProxyHandler(realSubject)
        );
        proxy.doSomething();
    }
}
