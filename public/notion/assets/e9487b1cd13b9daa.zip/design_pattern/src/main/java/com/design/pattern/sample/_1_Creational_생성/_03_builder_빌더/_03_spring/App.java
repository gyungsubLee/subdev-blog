package com.design.pattern.sample._1_Creational_생성._03_builder_빌더._03_spring;

import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

public class App {

    public static void main(String[] args) {
        // spring framework에서 제공하는 uriComponents는 builder 패턴을 통해 쉽게 url을 만들 수 있도록 제공
        UriComponents howToStudyJava = UriComponentsBuilder.newInstance()
                .scheme("http")
                .host("spartacodingclub.kr")
                .path("java playlist ep1")
                .build().encode();
        System.out.println(howToStudyJava);
    }
}
