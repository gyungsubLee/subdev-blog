package com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._02_java;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class App {

    public static void main(String[] args) {
        ArrayList list = new ArrayList<>();
        list.add(new Book());
        // collections는 여러가지 데코레이션 패턴을 적용한 메소들를 가지고 있습니다.

        // checkedList: 런타임에서 제네릭 타입을 보장해 실수로 잘못된 타입의 객체를 추가하는 것을 방지
        List books = Collections.checkedList(list, Book.class);

        try {
            list.add(new Item()); // 허용됨
            books.add(new Item()); // ClassCastException 발생
        } catch (ClassCastException e) {
            System.out.println("ClassCastException: 책 인스턴스만 추가할 수 있어요!");
        }

        // unmodifiableList: 읽기 전용으로 감싸서 리스트의 무결성을 보호
        List unmodifiableList = Collections.unmodifiableList(list);
        try {
            unmodifiableList.add(new Book()); // UnsupportedOperationException 발생
        } catch (UnsupportedOperationException e) {
            System.out.println("UnsupportedOperationException: list를 수정할 수 없어요!");
        }
    }
}
