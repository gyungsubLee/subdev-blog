package com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._02_spring;

/**
 * Event
 * 이벤트의 데이터를 캡슐화하는 역할
 * 이벤트가 발생했을 때 전달할 메시지를 담고 있음
 * */
public class MyEvent {

    private String message;

    public MyEvent(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
