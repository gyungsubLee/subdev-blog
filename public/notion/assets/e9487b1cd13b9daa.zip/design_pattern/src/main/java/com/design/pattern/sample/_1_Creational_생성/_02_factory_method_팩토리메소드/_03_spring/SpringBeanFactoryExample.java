package com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._03_spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringBeanFactoryExample {

    // Spring에서는 다양한 방식으로 bean을 등록할 수 있도록 BeanFactory를 제공합니다.
    public static void main(String[] args) {
        // ClassPathXmlApplicationContext : 제품(xml파일)을 BeanFactory에 구체적 생성인 ClassPathXmlApplicationContext로 생성
        BeanFactory xmlFactory = new ClassPathXmlApplicationContext("config.xml");
        String hello = xmlFactory.getBean("hello", String.class);
        System.out.println(hello);

        // AnnotationConfigApplicationContext : 제품(java파일)을 BeanFactory에 구체적 생성인 AnnotationConfigApplicationContext 생성
        BeanFactory javaFactory = new AnnotationConfigApplicationContext(Config.class);
        String hi = javaFactory.getBean("hello", String.class);
        System.out.println(hi);
    }
}
