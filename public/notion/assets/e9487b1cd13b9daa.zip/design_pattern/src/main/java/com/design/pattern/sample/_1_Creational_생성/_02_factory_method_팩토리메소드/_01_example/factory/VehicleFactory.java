package com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.factory;

import com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.product.Transport;
import com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._01_example.product.Vehicle;

/**
 * 구체적 생성자
 * 구체적 제품에 생성 역할을 담당하는 객체
 */
public class VehicleFactory implements TransportFactory {

    @Override
    public Transport create() {
        return new Vehicle();
    }
}
