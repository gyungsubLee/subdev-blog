package com.design.pattern.sample._2_Structural_구조._02_proxy_대리인._02_example;


/**
 * RealSubject
 * 실제 업무를 수행할 객체
 * */
public class RealSubject implements Subject {

    public void doSomething() {
        System.out.println("메소드 실행");
    }
}