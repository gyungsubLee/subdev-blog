package com.design.pattern.sample._1_Creational_생성._01_singleton_싱글톤._4_spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

    /**
    * 스프링 프레임워크에서는 내부적으로 클래스의 제어를 Ioc(Inversion Of Control) 방식의 컨테이너에게 위임하기 때문에
    * Bean으로 등록된 모든 객체는 싱글턴과 같은 효과로 하나의 인스턴스만 존재할 수 있게 합니다.
    * */
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(SpringConfig.class);
        String hello = applicationContext.getBean("initConfig", String.class);
        String hello2 = applicationContext.getBean("initConfig", String.class);
        System.out.println(hello == hello2);
    }

}
