package com.design.pattern.sample._3_Behavioral_행동._01_template_템플릿._01_example;

/**
 * 구체적 클래스
 * 추상 템플릿 클래스를 구체적으로 구현한 클래스로 상속 메소드를 구현
 * */
class TossPayProcessor extends PaymentProcessor {

    @Override
    protected void authenticate() {
        System.out.println("토스 계정을 인증합니다.");
    }

    @Override
    protected void processTransaction(double amount) {
        System.out.println("토스페이로 " + amount + "원을 결제합니다.");
    }
}