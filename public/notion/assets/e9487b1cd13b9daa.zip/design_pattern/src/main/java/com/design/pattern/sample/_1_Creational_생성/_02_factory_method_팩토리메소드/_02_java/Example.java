package com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._02_java;

import java.sql.SQLException;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Locale;

public class Example {

    public static void main(String[] args) throws SQLException {
        // 싱글턴을 사용한 정적 팩토리 메소드로 만들어진 객체 활용
        // 정적 팩토리 메소드 : 생성자가 아닌 static 메소드로 객체를 생성하는 방식
        Sample instance = Sample.getInstance();

        // 달력을 생성하는 메소드로 지역(locale)따라 적절한 하위 클래스를 반환합니다.
        System.out.println(
                Calendar.getInstance().getClass()
        ); // 기본 GregorianCalendar.java
        System.out.println(
                Calendar.getInstance(
                        Locale.forLanguageTag("ko-KR-x-lvariant-Modern")
                ).getClass()
        ); // 한국 : GregorianCalendar
        System.out.println(
                Calendar.getInstance(
                        Locale.forLanguageTag("ar-SA-u-ca-islamic")
                ).getClass()
        ); // 일본 : JapaneseImperialCalendar

        // 지역에 맞는 화폐, 퍼센트, 숫자등을 포맷팅할 수 있도록 지원합니다.
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
        NumberFormat percentFormatter = NumberFormat.getPercentInstance();
        NumberFormat numberInstance = NumberFormat.getNumberInstance();

        double x = 520;
        System.out.println(currencyFormatter.format(x)); // ₩520
        System.out.println(percentFormatter.format(x)); // 10%
        StringBuffer buffer = new StringBuffer();
        buffer.append(100);
        System.out.println(numberInstance.format(x, buffer, new FieldPosition(NumberFormat.FRACTION_FIELD))); // 100520

    }
}
