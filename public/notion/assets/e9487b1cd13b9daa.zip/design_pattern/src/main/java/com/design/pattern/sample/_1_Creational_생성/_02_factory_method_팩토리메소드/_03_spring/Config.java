package com.design.pattern.sample._1_Creational_생성._02_factory_method_팩토리메소드._03_spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {

    @Bean
    public String hello() {
        return "hello";
    }

}
