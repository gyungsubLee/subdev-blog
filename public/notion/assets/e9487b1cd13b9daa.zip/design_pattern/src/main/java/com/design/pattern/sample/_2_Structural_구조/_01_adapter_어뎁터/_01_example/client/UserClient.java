package com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.client;

import com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adapter.UserDetails;
import com.design.pattern.sample._2_Structural_구조._01_adapter_어뎁터._01_example.adapter.UserDetailsService;
import lombok.RequiredArgsConstructor;

 /**
  * 클라이언트
  * login을 요청한 클라이언트로 클라이언트 인터페이스(userDetailsService)로 부터 호출한 결과를 받음
  * */
@RequiredArgsConstructor
public class UserClient {

    private final UserDetailsService userDetailsService;

    public String login(String username, String password) {
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
        if (userDetails.getPassword().equals(password)) {
            return userDetails.getUsername();
        } else {
            throw new IllegalArgumentException();
        }
    }
}
