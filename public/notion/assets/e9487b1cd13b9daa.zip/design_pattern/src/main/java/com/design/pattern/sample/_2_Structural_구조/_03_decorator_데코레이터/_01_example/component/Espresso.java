package com.design.pattern.sample._2_Structural_구조._03_decorator_데코레이터._01_example.component;

/**
 *  구체적 컴포넌트
 *  기본 음료를 정의합니다.
 *  */
public class Espresso implements Beverage {
    @Override
    public String getDescription() {
        return "에스프레소";
    }

    @Override
    public double getCost() {
        return 5000.0;
    }
}