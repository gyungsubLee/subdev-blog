package com.design.pattern.sample._3_Behavioral_행동._03_observer_관찰자._01_example.observer;

/**
 * 괸찰자 인터페이스
 * 옵저버 패턴에서 구독자 역할을 하는 객체가 구현해야 하는 인터페이스
 * update() 메서드를 통해 상태 변화에 대한 알림을 받도록 선언
 * */
public interface Observer {
    void update(String stockSymbol, double price);
}