package com.design.pattern.sample._1_Creational_생성._01_singleton_싱글톤._2_case;

import java.io.Serializable;

/**
 * case 2 : static inner 클래스를 사용하여 instance 생성 시 static화시키는 방법 (권장)
 * ** 해당 코드로 작성 시 직력화/역직열화, 멀티쓰레드 환경에서도 사용 가능
 */
public class Sample implements Serializable {

    private Sample() { }

    private static class SampleHolder {
        private static final Sample INSTANCE = new Sample();
    }

    public static Sample getInstance() {
        return SampleHolder.INSTANCE;
    }

}
