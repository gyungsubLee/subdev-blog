# 📐 Design Patterns

## 📌 프로젝트 소개
이 프로젝트는 GoF(GoF: Gang of Four) 디자인 패턴에 일부를 설명합니다.

## 📑 내용 (Table of Contents)
- [📂 디자인 패턴 목록]
- **생성 패턴 (Creational Patterns)**
    - 싱글톤 (Singleton)
    - 팩토리 메서드 (Factory Method)
    - 빌더 (Builder)
    
      <제외>
    - 추상 팩토리 (Abstract Factory)
    - 프로토타입 (Prototype)

- **구조 패턴 (Structural Patterns)**
    - 어댑터 (Adapter)
    - 대리인 (Proxy)
    - 데코레이터 (Decorator)
     
      <제외>
    - 브릿지 (Bridge)
    - 조합 (Composite)
    - 정면 (Facade)
    - 가벼운무게 (Flyweight)

- **행동 패턴 (Behavioral Patterns)**
    - 탬플릿 (Template)
    - 전략 (Strategy)
    - 관찰자 (Observer)
      
      <제외>
    - 책임 연쇄 (Chain of Responsibility)
    - 명령 (Command)
    - 통역사 (Interpreter)
    - 반복자 (Iterator)
    - 중재자 (Mediator)
    - 기억의 증표 (Memento)
    - 상태 (State)
    - 방문자 (Visitor)