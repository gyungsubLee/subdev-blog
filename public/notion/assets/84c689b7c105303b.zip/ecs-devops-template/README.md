# ECS DevOps Template

This is a full-featured ECS + Docker + CI/CD + Monitoring setup.
