package com.example.performance.service;

import com.example.performance.entity.Account;
import com.example.performance.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AccountService {

    private final AccountRepository accountRepository;

    @Cacheable(value = "accountCache", key = "#id")
    public Account findById(Long id) {
        return accountRepository.findById(id).orElse(null);
    }

}
