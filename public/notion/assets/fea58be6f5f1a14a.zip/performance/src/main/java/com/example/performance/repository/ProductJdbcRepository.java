package com.example.performance.repository;

import com.example.performance.entity.Product;

import java.util.List;

public interface ProductJdbcRepository {
    void batchInsert(List<Product> productList);
}
