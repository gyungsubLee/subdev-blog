package com.example.performance.repository;

import com.example.performance.entity.Product;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class ProductJdbcRepositoryImpl implements ProductJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    @Transactional
    public void batchInsert(List<Product> productList) {
        String sql = "INSERT INTO products(`name`, `price`) VALUES (?, ?)";

        int size = productList.size();
        jdbcTemplate.batchUpdate(sql, productList, size,
            (PreparedStatement ps, Product product) -> {
                ps.setString(1, product.getName());
                ps.setInt(2, product.getPrice());
            }
        );
    }
}
