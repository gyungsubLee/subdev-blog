package com.example.performance.controller;

import com.example.performance.service.AccountService;
import com.example.performance.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
public class MyController {

    private final AccountService accountService;
    private final ProductService productService;

    @GetMapping("/second-cache")
    public void getMember() {
        accountService.findById(1L);
    }

    @GetMapping("/batch-insert")
    public void batchInsert() {
        productService.batchInsert();
    }
}
