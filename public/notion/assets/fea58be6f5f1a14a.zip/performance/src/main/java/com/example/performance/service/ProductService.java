package com.example.performance.service;

import com.example.performance.entity.Product;
import com.example.performance.repository.ProductJdbcRepository;
import com.example.performance.repository.ProductRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductJdbcRepository productJdbcRepository;

    @Transactional
    public void batchInsert() {
        List<Product> accountList = new ArrayList<>();
        for (int i=1; i<50; i++) {
            accountList.add(new Product("상품 이름" + i, i * 100));
        }

        productJdbcRepository.batchInsert(accountList);
    }
}
