package com.example.performance.repository;

import com.example.performance.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountRepository extends JpaRepository<Account, Long> {
    List<Account> findByIdIn(List<Long> accountIdList);
}