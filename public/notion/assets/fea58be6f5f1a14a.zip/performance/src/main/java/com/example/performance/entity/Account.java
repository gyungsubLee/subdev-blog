package com.example.performance.entity;

//import jakarta.persistence.*;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@Getter
@ToString
@NoArgsConstructor
@Entity
@Table(name = "accounts")
public class Account {

    @Id
    @Column(name = "account_id")
    private Long id;

    private String name;    // 예금주

    private String number;  // 계좌번호

    public Account(Long id, String name, String number) {
        this.id = id;
        this.name = name;
        this.number = number;
    }

}