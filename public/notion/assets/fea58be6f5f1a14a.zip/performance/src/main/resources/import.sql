INSERT INTO accounts(account_id, name, number) VALUES (1, '김재연', '1002-058-568181');
INSERT INTO accounts(account_id, name, number) VALUES (2, '스파르타', '1234-5678-910');

