package com.example.performance;

import com.example.performance.entity.Account;
import com.example.performance.repository.AccountRepository;
import com.example.performance.service.AccountService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)    // h2 DB 사용 X
class PerformanceApplicationTests {

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    AccountService accountService;

    @Test
    void beforeRefactoringTest() {
        List<Long> accountIdList = new ArrayList<>();
        for (long i=1; i<50; i++) {
            accountIdList.add(i);
        }

        for (Long accountId : accountIdList) {
            Account account = accountRepository.findById(accountId).orElse(null);

            /**
             * account 관련 작업 수행
             */
        }
    }

    @Test
    void afterRefactoringTest() {
        List<Long> accountIdList = new ArrayList<>();
        for (long i=1; i<1000; i++) {
            accountIdList.add(i);
        }

        List<Account> accountList = accountRepository.findByIdIn(accountIdList);

        /**
         * account 관련 작업 수행
         */
    }

    @Test
//    @Transactional
    void withoutSecondCache() {
        Account account1 = accountRepository.findById(1L).orElse(null);
        Account account2 = accountRepository.findById(1L).orElse(null);
    }

    @Test
    void withSecondCache() {
        Account account1 = accountService.findById(1L);
        Account account2 = accountService.findById(1L);
        System.out.println(account1);
        System.out.println(account2);
    }

    @Test
    void secondCacheExpired() throws InterruptedException {
        Account account1 = accountService.findById(1L);
        Thread.sleep(3000);
        Account account2 = accountService.findById(1L);
        System.out.println(account1);
        System.out.println(account2);
    }


    @Test
    void batchInsertTest() throws SQLException {
        String sql = "INSERT INTO members (member_id, name, email) VALUES (?, ?, ?)";
//        memberService.batchInsert();
//        try (Connection connection = dataSource.getConnection();
//             PreparedStatement ps = connection.prepareStatement(sql)) {
//            connection.setAutoCommit(false);
//
//            for (Member member : memberList) {
//                ps.setLong(1, member.getId());
//                ps.setString(2, member.getName());
//                ps.setString(3, member.getEmail());
//                ps.addBatch();
//            }
//
//            int[] batchResults = ps.executeBatch();
//            connection.commit();
//
//            // 실행된 쿼리 개수 확인
//            int executedQueries = batchResults.length;
//            System.out.println("Executed queries count: " + executedQueries);
//        } catch (SQLException e) {
//            throw new RuntimeException("Batch insert failed", e);
//        }
//        System.out.println("Insert Complete!");
    }

}
