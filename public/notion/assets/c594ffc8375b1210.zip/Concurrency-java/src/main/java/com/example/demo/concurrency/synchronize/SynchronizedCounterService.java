package com.example.demo.concurrency.synchronize;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SynchronizedCounterService {

    private final SynchronizedCounterRepository synchronizedCounterRepository;

    public void save(SynchronizedCounter synchronizedCounter) {
        synchronizedCounterRepository.save(synchronizedCounter);
    }

    public void reset() {
        SynchronizedCounter synchronizedCounter = synchronizedCounterRepository.findById(1L).orElseThrow();
        synchronizedCounter.initCount();
        synchronizedCounterRepository.save(synchronizedCounter);
    }

    public void decreaseCount() {
        SynchronizedCounter synchronizedCounter = synchronizedCounterRepository.findById(1L).orElseThrow();
        synchronizedCounter.decreaseCount();
        synchronizedCounterRepository.save(synchronizedCounter);
    }

    public synchronized void decreaseCountWithSynchronized() {
        SynchronizedCounter synchronizedCounter = synchronizedCounterRepository.findById(1L).orElseThrow();
        synchronizedCounter.decreaseCount();
        synchronizedCounterRepository.save(synchronizedCounter);
    }

    @Transactional
    public synchronized void decreaseCountWithSynchronizedAndTransactional() {
        SynchronizedCounter synchronizedCounter = synchronizedCounterRepository.findById(1L).orElseThrow();
        synchronizedCounter.decreaseCount();
        synchronizedCounterRepository.save(synchronizedCounter);
    }

    public void printCount() {
        SynchronizedCounter synchronizedCounter = synchronizedCounterRepository.findById(1L).orElseThrow();
        System.out.println("count = " + synchronizedCounter.getCount());
    }
}
