package com.example.demo.concurrency.redis;

import lombok.RequiredArgsConstructor;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
public class CounterService {

    private final CounterRepository counterRepository;
    private final RedissonClient redissonClient;
    private final RedisTemplate<String, Long> redisTemplate;

    private static final String LOCK_KEY = "counterLock";

    @Transactional
    public void save(Counter counter) {
        counterRepository.save(counter);
    }

    @Transactional
    public void reset() {
        Counter counter = counterRepository.findById(1L).orElseThrow();
        counter.initCount();
        counterRepository.save(counter);
    }

    @Transactional
    public void decreaseCount() {
        Counter counter = counterRepository.findById(1L).orElseThrow();
        counter.decreaseCount();
        counterRepository.save(counter);
    }

    @Transactional
    public void decreaseCountUsingLock() {
        RLock lock = redissonClient.getFairLock(LOCK_KEY);
        try {
            boolean isLocked = lock.tryLock(10, 60, TimeUnit.SECONDS);
            if (isLocked) {
                Counter counter = counterRepository.findById(1L).orElseThrow();
                counter.decreaseCount();
                counterRepository.save(counter);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }
    }

    public void initializeCounter() {
        ValueOperations<String, Long> ops = redisTemplate.opsForValue();
        ops.set("counter", 1000L);
    }

    public void decrementCounter() {
        ValueOperations<String, Long> ops = redisTemplate.opsForValue();
        ops.decrement("counter");
    }

    public void getCounter() {
        ValueOperations<String, Long> ops = redisTemplate.opsForValue();
        Long value = ops.get("counter");
        System.out.println(value);
    }

    public void printCount() {
        System.out.println("\n\n\n====================\n");
        System.out.println(counterRepository.findById(1L).orElseThrow().getCount());
        System.out.println("\n====================\n\n\n");
    }
}
