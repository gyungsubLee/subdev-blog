package calculator.Step4.operation;

public abstract class AbstractOperation {
    public abstract double calculate(double a, double b);
}
