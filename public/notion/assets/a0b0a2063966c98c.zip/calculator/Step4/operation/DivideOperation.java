package calculator.Step4.operation;

public class DivideOperation extends AbstractOperation {
    @Override
    public double calculate(double a, double b) {
        return a / b;
    }
}
