package calculator.Step4;

import calculator.Step4.operation.AddOperation;
import calculator.Step4.operation.DivideOperation;
import calculator.Step4.operation.MultiplyOperation;
import calculator.Step4.operation.SubstractOperation;

public class Main {
    public static void main(String[] args) {
        Calculator calculator  = new Calculator(new AddOperation());
        System.out.println(calculator.calculate(10, 20));
        calculator.setOperation(new MultiplyOperation());
        System.out.println(calculator.calculate(10, 20));
    }
}