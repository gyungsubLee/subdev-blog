package calculator.Step5.operation;

public interface Operation {
    double calculate(double a, double b);
}
