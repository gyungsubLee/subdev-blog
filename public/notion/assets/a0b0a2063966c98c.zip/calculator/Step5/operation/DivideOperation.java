package calculator.Step5.operation;

public class DivideOperation implements Operation {
    @Override
    public double calculate(double a, double b) {
        return a / b;
    }
}
