package calculator.Step3;

import calculator.Step3.operation.AddOperation;
import calculator.Step3.operation.DivideOperation;
import calculator.Step3.operation.MultiplyOperation;
import calculator.Step3.operation.SubstractOperation;

public class Main {
    public static void main(String[] args) {
        Calculator calculator  = new Calculator(new AddOperation(), new SubstractOperation(),
                new MultiplyOperation(), new DivideOperation());
        System.out.println(calculator.calculate("+", 10, 20));
        System.out.println(calculator.calculate("*", 10, 20));

    }
}