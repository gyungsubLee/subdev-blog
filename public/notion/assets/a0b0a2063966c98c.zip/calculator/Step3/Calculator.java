package calculator.Step3;


import calculator.Step3.operation.AddOperation;
import calculator.Step3.operation.DivideOperation;
import calculator.Step3.operation.MultiplyOperation;
import calculator.Step3.operation.SubstractOperation;

// @RequiredArgsConstructor
public class Calculator {

    private final AddOperation addOperation;
    private final SubstractOperation substractOperation;
    private final MultiplyOperation multiplyOperation;
    private final DivideOperation divideOperation;

    public Calculator(AddOperation addOperation, SubstractOperation substractOperation, MultiplyOperation multiplyOperation, DivideOperation divideOperation) {
        this.addOperation = addOperation;
        this.substractOperation = substractOperation;
        this.multiplyOperation = multiplyOperation;
        this.divideOperation = divideOperation;
    }

    public double calculate(String operator, int num1, int num2) {
        double answer = 0;

        if(operator.equals("+")){
            answer = addOperation.calculate(num1, num2);
        }else if(operator.equals("-")){
            answer = substractOperation.calculate(num1, num2);
        }else if(operator.equals("*")){
            answer = multiplyOperation.calculate(num1, num2);
        }else if(operator.equals("/")) {
            answer = divideOperation.calculate(num1, num2);
        }
        return answer;
    }
}
