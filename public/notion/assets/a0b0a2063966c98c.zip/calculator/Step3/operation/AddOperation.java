package calculator.Step3.operation;

public class AddOperation{
    public double calculate(double a, double b) {
        return a + b;
    }
}
