package calculator.Step3.operation;

public class MultiplyOperation{
    public double calculate(double a, double b) {
        return a * b;
    }
}
